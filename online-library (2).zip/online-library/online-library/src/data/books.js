export const books = [
  {
    id: 1,
    title: "1984",
    author: "George Orwell",
    description: "Dystopian novel",
    rating: 4.5
  },
  {
    id: 2,
    title: "Sapiens",
    author: "Yuval Noah Harari",
    description: "History of humankind",
    rating: 4.7
  },
  {
    id: 3,
    title: "Dune",
    author: "Frank Herbert",
    description: "Epic science fiction story",
    rating: 4.6
  }
];
import { Link } from "react-router-dom";

export default function BookCard({ book }) {
  return (
    <div className="bg-white rounded-lg shadow-lg hover:shadow-2xl transition transform hover:-translate-y-1 p-5 flex flex-col justify-between">
      <div>
        <h2 className="font-bold text-xl mb-2">{book.title}</h2>
        <p className="text-gray-700 mb-1">Author: {book.author}</p>
        <p className="text-gray-500 mb-2">Category: {book.category}</p>
        <p className="text-yellow-500 font-semibold">Rating: {book.rating}</p>
      </div>
      <Link 
        to={`/book/${book.id}`} 
        className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-center transition"
      >
        View Details
      </Link>
    </div>
  );
}
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

function Home(){

const books = useSelector(state => state.books);

return(

<div className="container">

<h1>Welcome to Online Library</h1>

<h2>Popular Books</h2>

<div className="grid">

{books.map(book => (

<div className="card" key={book.id}>

<h3>{book.title}</h3>

<p>Author: {book.author}</p>

<p>Rating: {book.rating}</p>

<Link to={`/books/${book.id}`}>
View Details
</Link>

</div>

))}

</div>

</div>

);

}

export default Home;
import { useState } from "react";
import { useDispatch } from "react-redux";
import { addBook } from "../redux/bookSlice";
import { useNavigate } from "react-router-dom";

function AddBook(){

const [title,setTitle] = useState("");
const [author,setAuthor] = useState("");
const [description,setDescription] = useState("");

const dispatch = useDispatch();
const navigate = useNavigate();

const handleSubmit = (e)=>{

e.preventDefault();

if(!title || !author || !description){
alert("Please fill all fields");
return;
}

dispatch(addBook({
id:Date.now(),
title,
author,
description,
rating:4
}));

navigate("/books");

};

return(

<div className="container">

<h1>Add Book</h1>

<form onSubmit={handleSubmit}>

<input
type="text"
placeholder="Title"
onChange={(e)=>setTitle(e.target.value)}
/>

<br/>

<input
type="text"
placeholder="Author"
onChange={(e)=>setAuthor(e.target.value)}
/>

<br/>

<input
type="text"
placeholder="Description"
onChange={(e)=>setDescription(e.target.value)}
/>

<br/>

<button type="submit">
Add Book
</button>

</form>

</div>

);

}

export default AddBook;
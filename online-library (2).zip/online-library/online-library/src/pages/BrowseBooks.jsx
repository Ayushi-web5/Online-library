import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { useState } from "react";

function BrowseBooks(){

const books = useSelector(state => state.books);

const [search,setSearch] = useState("");

const filteredBooks = books.filter(book =>
book.title.toLowerCase().includes(search.toLowerCase()) ||
book.author.toLowerCase().includes(search.toLowerCase())
);

return(

<div className="container">

<h1>Browse Books</h1>

<input
type="text"
placeholder="Search by title or author"
onChange={(e)=>setSearch(e.target.value)}
/>

<div className="grid">

{filteredBooks.map(book => (

<div className="card" key={book.id}>

<h3>{book.title}</h3>

<p>{book.author}</p>

<Link to={`/books/${book.id}`}>
View Details
</Link>

</div>

))}

</div>

</div>

);

}

export default BrowseBooks;